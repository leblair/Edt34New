package com.example.edt34;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;

import java.util.ArrayList;
import java.util.List;

public class ReservaActivity extends AppCompatActivity {

    private Spinner spinner;
    private ImageView imageReserva;
    private Switch aSwitch;
    private RadioGroup radioGroup;
    private RadioButton capButton;

    List<String> refugesList = new ArrayList<>();
    List<Integer> imageList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserva);

        spinner = findViewById(R.id.spinner);
        imageReserva = findViewById(R.id.imageReserva);
        aSwitch = findViewById(R.id.switchPensio);
        radioGroup = findViewById(R.id.radioGroup);
        capButton = findViewById(R.id.cap);

        refugesList.add(0, "Selecciona Refugi");
        refugesList.add("Refugi Josep Maria Blanc");
        refugesList.add("Refugi Cap de Llauset");
        refugesList.add("Refugi Ventosa i Clavell");
        refugesList.add("Refugi Amitges");
        refugesList.add("Refugi Josep Maria Montfort");

        imageList.add(0);
        imageList.add(R.drawable.foto1);
        imageList.add(R.drawable.foto2);
        imageList.add(R.drawable.foto3);
        imageList.add(R.drawable.foto4);
        imageList.add(R.drawable.foto5);


        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(
                this,
                R.layout.support_simple_spinner_dropdown_item,
                refugesList
        );
        spinner.setAdapter(dataAdapter);
        radioGroup.setAlpha(0f);

        Intent intent = getIntent();
        String text_Title = intent.getStringExtra(DashboardActivity.TITLE);
        int imageDefault = intent.getIntExtra(DashboardActivity.IMAGE,0);
        imageReserva.setImageResource(imageDefault);
        for(int i =0; i<refugesList.size();i++){
            if(text_Title.equals(refugesList.get(i))){
                spinner.setSelection(i);
            }
        }
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                imageReserva.setImageResource(imageList.get(i));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
//aaa
            }
        });

        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b)
                radioGroup.setAlpha(1f);
                else
                    capButton.setChecked(true);

            }
        });


        //texttitle.setText(textTitle);
        /*spinnerPerJava.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {@Overridepublic void onItemSelected(AdapterView<?> parent, View view, int position, long id) {// Get Selected value name from the listString selectedCondition = parent.getItemAtPosition(position).toString();        Toast.makeText(MainActivity.this,selectedCondition , Toast.LENGTH_SHORT).show();    }@Overridepublic void onNothingSelected(AdapterView<?> parent) {        Toast.makeText(MainActivity.this, "Nothing Selected", Toast.LENGTH_SHORT).show();    }});
         * */
    }
}